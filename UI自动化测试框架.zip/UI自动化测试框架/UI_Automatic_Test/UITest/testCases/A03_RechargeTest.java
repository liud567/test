package testCases;

import java.math.BigDecimal;

import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testPages.*;
import common.*;

@Listeners({common.ErrorListener.class})
public class A03_RechargeTest extends BaseTest{
	@Test
	@Parameters({"startURL", "username1", "password1", "rechargenum" })
	public void doRechargeRight(String startURL, String username1, String password1, String rechargenum){
		String paypassword = "123456";
		driver = init.initAndLogin("Firefox", startURL, username1, password1);
		HomePage testhomepage = new HomePage(driver);
		String balancebefore = testhomepage.getBalanceValue();
		RechargePage1 testrechargepage1 = testhomepage.goToRecharge();
		RechargePage2 teserechargepage2 = testrechargepage1.goToNextStep();
		RechargeSuccessPage testrechargesuccesspage = teserechargepage2.doRecharge(rechargenum, paypassword);
		String message  = testrechargesuccesspage.getMessage();
		testhomepage = testrechargesuccesspage.goBack();
		String balanceafter = testhomepage.getBalanceValue();
		ae.assertEquals(message, "操作成功！","验证操作结果提示是否和预期一致");
//		System.out.println("12345");这样子的信息不会显示在report里，上面的信息才会
		//浮点类型的计算，会有精度上的问题，需要使用BigDecimal解决，见A04_WithdrawTest
		BigDecimal b1=new BigDecimal(balanceafter);
		BigDecimal b2=new BigDecimal(balancebefore);
		BigDecimal b3=new BigDecimal(rechargenum);
		ae.assertEquals(b1.subtract(b2).compareTo(b3), 0, "验证充值后金额增加是否正确");
		driver.quit();
	}

}
