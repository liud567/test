package testCases;
//以下程序用于加载指定xml中的测试用例并执行，完成后输出测试报告到指定目录
import java.io.File;
import java.util.ArrayList;
import java.util.List;

import org.testng.TestNG;

public class Run {
	public static void main(String[] args) {
		TestNG testNg = new TestNG();
		testNg.setUseDefaultListeners(false);
		List<String> suites = new ArrayList<String>();
		suites.add("UITest/testCases/testng.xml");
		testNg.setTestSuites(suites);
		File file = new File("UITest/testResult/测试报告");
		if(!file.exists()){
			file.mkdirs();
		}
		testNg.setOutputDirectory(file.getAbsolutePath());
		testNg.run();
	}

}
