package testCases;

import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testPages.*;
import common.*;

@Listeners({common.ErrorListener.class})
public class A02_BindingBankcardTest extends BaseTest{

	@Test
	@Parameters({"startURL", "username1", "password1", "bankcardid" })
	public void doBindingBankcardRight(String startURL, String username1, String password1, String bankcardid) {
		driver = init.initAndLogin("Firefox", startURL, username1, password1);
		HomePage hp = new HomePage(driver);
		AccountManagementPage ap = hp.goToAccountManageent();
		MyBankCardPage mp = ap.goToMyBankCardPage();
		int cardsnumbefore = mp.getCardsNum();
		ap = mp.goToAccountManageentPage();
		MyBankCardAddPage maddp = ap.goToMyBankCardAddPage();
		mp = maddp.doAddCard(bankcardid, username1);
		int cardsnumafter = mp.getCardsNum();
		ae.assertEquals(cardsnumafter - cardsnumbefore, 1, "通过对比绑卡前后，已绑定银行卡的数目变化验证操作是否成功");
		driver.quit();
	}

}
