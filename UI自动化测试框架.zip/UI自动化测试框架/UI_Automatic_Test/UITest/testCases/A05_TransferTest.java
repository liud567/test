package testCases;

import java.math.BigDecimal;

import org.testng.annotations.BeforeClass;
import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import common.*;
import testPages.*;


@Listeners({common.ErrorListener.class})
public class A05_TransferTest  extends BaseTest{
	
	@BeforeClass
	@Parameters({"startURL", "username2", "password2" ,"id2"})
	public void signinTarget(String startURL, String username2, String password2 ,String id2){
		driver = init.init("Firefox", startURL);
		FrontPage frontpage = new FrontPage(driver);
		SigninPage1 signpage1 = frontpage.goToSinginPage();
		SigninPage2 signinpage2 = signpage1.submitdata(username2, true, "010101", true);
		signinpage2.submitdata(password2, password2, "1234@tangdi.com", "自动化注册测试", id2,"您的小学名称", "12345");
		driver.quit();
	}
	
	@Test
	@Parameters({"startURL", "username1", "password1" ,"username2", "password2", "transfernum"})
	public void doTransferRight(String startURL, String username1, String password1, String username2, String password2, String transfernum){
		String paypassword = "111111";
		Init init = new Init();
		driver = init.initAndLogin("Firefox", startURL, username1, password1);
		HomePage hp = new HomePage(driver);
		String balancebefore = hp.getBalanceValue();
		TransferPage tp = hp.goToTransfer();
		tp.doTransfer(username2, transfernum, paypassword);
//		System.out.println(tp.getConfirmText());
//		{"accountTarget":"13400000001","amount":1,"txPassword":"111111"}
//		String expectedtext = "{\"accountTarget\":\""+ targetid+ "\",\"amount\":"+transfernum + ",\"txPassword\":\"" + paypassword + "\"}";
		hp = tp.goToHomePage();
		String balanceafter = hp.getBalanceValue();
		BigDecimal b1=new BigDecimal(balanceafter);
		BigDecimal b2=new BigDecimal(balancebefore);
		BigDecimal b3=new BigDecimal(transfernum);
		ae.assertEquals(b2.subtract(b1).compareTo(b3), 0, "验证转账完成后本账户金额减少是否正确");
		driver.quit();
	}

}
