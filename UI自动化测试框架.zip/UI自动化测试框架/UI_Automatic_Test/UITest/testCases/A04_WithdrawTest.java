package testCases;

import java.math.BigDecimal;

import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import common.*;
import testPages.*;



@Listeners({common.ErrorListener.class})
public class A04_WithdrawTest extends BaseTest{
	
	@Test
	@Parameters({"startURL", "username1", "password1", "withdrawnum" })
	public void doWithdrawRight(String startURL, String username1, String password1, String withdrawnum){
		driver = init.initAndLogin("Firefox", startURL, username1, password1);
		HomePage hp = new HomePage(driver);
		String balancebefore = hp.getBalanceValue();
		WithdrawPage wp = hp.goToWithdraw();
		wp.doWithDraw(withdrawnum, "111111");
		hp = wp.goToHomepage();
		String balanceafter = hp.getBalanceValue();
		BigDecimal b1=new BigDecimal(balanceafter);
		BigDecimal b2=new BigDecimal(balancebefore);
		BigDecimal b3=new BigDecimal(withdrawnum);
		//浮点数的计算会有误差,要精确计算，需使用BigDecimal
		//浮点数的比较无法严格比较，解决方法
		//1、用一个足够小的数来比较他们的差值，如果差值小于这个足够小的数，就当他们相等
		//这里的一个小问题是，这个足够小的数怎么定义？这个一般是个经验值，小数点后面七八个零一般认为就差不多了。
		//2、使用BigDecimal的compareTo
		//BigDecimal a=BigDecimal.valueOf(1.0);
		//BigDecimal b=BigDecimal.valueOf(1.000);
		//if(a.compareTo(b)==0) 结果是true
		ae.assertEquals(b2.subtract(b1).compareTo(b3),0, "验证提现后金额减少是否正确");
		driver.quit();
	}
}
