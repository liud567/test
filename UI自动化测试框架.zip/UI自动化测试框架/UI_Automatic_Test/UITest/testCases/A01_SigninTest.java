package testCases;

import org.testng.annotations.Listeners;
import org.testng.annotations.Parameters;
import org.testng.annotations.Test;

import testPages.*;
import common.*;

@Listeners({common.ErrorListener.class})
public class A01_SigninTest extends BaseTest{
	
	Log log=new Log(this.getClass());

	@Test
	@Parameters({"startURL", "username1", "password1" ,"id"})
	public void doSigninRight(String startURL, String username1, String password1 , String id){
		driver = init.init("Firefox", startURL);
		frontpage = new FrontPage(driver);
		signinpage1 = frontpage.goToSinginPage();
		signinpage2 = signinpage1.submitdata(username1, true, "010101", true);
		signinpage2.submitdata(password1, password1, "1234@tangdi.com", "自动化注册测试", id,"您的小学名称", "12345");
		waitMs(2000);
		String nowurl = driver.getCurrentUrl();
		ae.assertEquals(nowurl, "http://192.168.0.237:3000/#/0", "通过是否成功跳转来判断");
		driver.quit();
	}
	
//	@Test
//	public void doSigninWrong(){
//		String testusername = "13400000033";
//		String testpassword = "111111";
//		Init init = new Init();
//		driver = init.init("Firefox", Baseinfo.URL);
//		FrontPage frontpage = new FrontPage(driver);
//		SigninPage1 signpage1 = frontpage.goToSinginPage();
//		SigninPage2 signinpage2 = signpage1.submitdata(testusername, true, "010101", true);
//		signinpage2.submitdata(testpassword, testpassword, "1234@tangdi.com", "自动化注册测试", "360681199999999990","您的小学名称", "12345");
//		String nowurl = driver.getCurrentUrl();
////		Assert.assertEquals(nowurl, "http://220.248.44.250:53000/#/2", "通过是否成功跳转来判断");
//		driver.quit();
//	}
	
}
