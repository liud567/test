package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class WithdrawPage extends BasePage {
	public WithdrawPage(WebDriver driver){
		super(driver);
	}
	
	public void inputWithdrawNum(String num){
		getElement("withdrawpage_inputwithdrawnum_input").sendKeys(num);
	}
	
	public void inputPayPassword(String paypassword){
		getElement("withdrawpage_inputpaypassword_input").sendKeys(paypassword);
	}
	
	public void doSubmit(){
		getElement("withdrawpage_submit_button").click();
	}
	
	public void doWithDraw(String num, String paypassword){
		inputWithdrawNum(num);
		inputPayPassword(paypassword);
		doSubmit();
	}
	
	public HomePage goToHomepage(){
		getElement("withdrawpage_homepage_button").click();
		return new HomePage(driver);
	}
	
}
