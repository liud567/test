package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class LoginPage extends BasePage {
	public LoginPage(WebDriver driver){
		super(driver);
	}
	
	public void inputUsername(String username){
		clear("loginpage_inputusername_input");
		type("loginpage_inputusername_input", username);
	}
	
	public void inputPassword(String password){
		clear("loginpage_inputpassword_input");
		type("loginpage_inputpassword_input", password);
	}
	
	public void remenberinfo(Boolean rememberinfo){
		if(rememberinfo==true){
			click("loginpage_rememberinfo_checkbox");
		}
	}
	
	public void doLogin(){
		click("loginpage_loginbutton_button");
	}
	
	public HomePage doLogin(String username, String password, Boolean rememberinfo){
		inputUsername(username);
		inputPassword(password);
		remenberinfo(rememberinfo);
		doLogin();
		return new HomePage(driver);
	}
	
}
