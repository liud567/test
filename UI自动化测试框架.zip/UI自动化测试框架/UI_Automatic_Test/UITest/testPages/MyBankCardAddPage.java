package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class MyBankCardAddPage extends BasePage {
	public MyBankCardAddPage(WebDriver driver){
		super(driver);
	}
	
	public void inputCardId(String cardid){
//		getElement("mybankcardaddpage_inputcardid_input").sendKeys(cardid);
		type("mybankcardaddpage_inputcardid_input", cardid);
	}
	
	public void inputPhoneNum(String phonenum){
//		getElement("mybankcardaddpage_inputphonenum_input").sendKeys(phonenum);
		type("mybankcardaddpage_inputphonenum_input", phonenum);
	}
	
	public void getVerifyCode(){
		click("mybankcardaddpage_getverifyCode_button");
	}
	
	public void inputVerifyCode(String verifycode){
		type("mybankcardaddpage_inputverifyCode_input", verifycode);
	}
	
	public void doSubmit(){
//		getElement("mybankcardaddpage_submit_button").click();
		click("mybankcardaddpage_submit_button");
	}
	
	public MyBankCardPage doAddCard(String cardid, String phonenum){
		inputCardId(cardid);
		inputPhoneNum(phonenum);
		getVerifyCode();
		inputVerifyCode("010101");
		doSubmit();
		return new MyBankCardPage(driver);
	}
}
