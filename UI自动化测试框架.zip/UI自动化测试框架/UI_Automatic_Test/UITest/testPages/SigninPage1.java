package testPages;


import org.openqa.selenium.WebDriver;

import common.BasePage;

public class SigninPage1 extends BasePage {
	
	public SigninPage1(WebDriver driver){
		super(driver);
	}
	
	public void selectCountry(){
		click("signinpage1_selectcountry_button");
		click("signinpage1_selectcountry_value1");
	}
	
	public void selectPhoneareacode(){
		click("signinpage1_selectphoneareacode_button");
		click("signinpage1_selectphoneareacode_value1");
	}
	
	public void inputphonenumber(String phonenumber){
		type("signinpage1_inputphonenumber_input", phonenumber);
	}
	
	public void getverificationcode(Boolean doget){
		if(doget==true){
			click("signinpage1_inputverificationcode_input");
			click("signinpage1_getverificationcode_button");
		}
	}
	
	public void inputverificationcode(String verificationcode){
		type("signinpage1_inputverificationcode_input", verificationcode);
	}
	
	public void checkagreement(Boolean agree){
		if(agree==false){
			click("signinpage1_checkagreement_box");
		}
	}
	
	public void doSubmit(){
		click("signinpage1_submitbutton_button");
	}
	
	public SigninPage2 submitdata(String phonenumber, Boolean getcode, String verificationcode, Boolean agreementcheck){
//		selectCountry();
//		selectPhoneareacode();
		inputphonenumber(phonenumber);
		getverificationcode(getcode);
		inputverificationcode(verificationcode);
		checkagreement(agreementcheck);
		doSubmit();
		
		return new SigninPage2(driver);
	}

}
