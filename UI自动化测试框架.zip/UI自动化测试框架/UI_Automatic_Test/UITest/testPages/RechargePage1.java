package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class RechargePage1 extends BasePage {
	public RechargePage1(WebDriver driver){
		super(driver);
	}
	
	public void selectBankCard(){
		getElement("rechargepage1_bankcard1_button").click();
	}
	
	public void submit(){
		getElement("rechargepage1_nextstep_button").click();
	}
	
	public RechargePage2 goToNextStep(){
		selectBankCard();
		submit();
		return new RechargePage2(driver);
	}
	
}
