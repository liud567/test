package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class RechargeSuccessPage extends BasePage {
	public RechargeSuccessPage(WebDriver driver){
		super(driver);
	}
	
	public String getMessage(){
		String message = getElement("rechargesuccesspage_message_text").getText();
		return message;
	}
	
	public HomePage goBack(){
		getElement("rechargesuccesspage_back_button").click();
		return new HomePage(driver);
	}
}
