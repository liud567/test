package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class FrontPage extends BasePage {
	
	public FrontPage(WebDriver driver){
		super(driver);
	}

	public SigninPage1 goToSinginPage(){
		click("frontpage_signin_button");
		return new SigninPage1(driver);
	}
	
	public LoginPage goToLoginPage(){
		click("frontpage_login_button");
		return new LoginPage(driver);
	}

}
