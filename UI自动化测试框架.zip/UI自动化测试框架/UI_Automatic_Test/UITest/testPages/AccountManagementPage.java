package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class AccountManagementPage extends BasePage {
	public AccountManagementPage(WebDriver driver){
		super(driver);
	}
	
	public MyBankCardAddPage goToMyBankCardAddPage(){
		getElement("accountmanagementpage_addbankcard_button").click();
		return new MyBankCardAddPage(driver);
	}
	
	public MyBankCardPage goToMyBankCardPage(){
		getElement("accountmanagementpage_managebankcard_button").click();
		return new MyBankCardPage(driver);
	}
	
}
