package testPages;

import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;

import common.BasePage;

public class TransferPage extends BasePage {
	public TransferPage(WebDriver driver){
		super(driver);
	}
	
	public void inputTargetId(String id){
		getElement("transferpage_inputtargetid_input").sendKeys(id);
	}
	
	public void inputTransferNum(String num){
		getElement("transferpage_inputtransfernum_input").sendKeys(num);
	}
	
	public void inputPayPassword(String paypassword){
		getElement("transferpage_inputpaypassword_input").sendKeys(paypassword);
	}
	
	public void doSubmit(){
		getElement("transferpage_submit_button").click();
	}
	
	public void doTransfer(String id, String num, String paypassword){
		inputTargetId(id);
		inputTransferNum(num);
		inputPayPassword(paypassword);
		doSubmit();
	}
	
	public HomePage goToHomePage(){
		getElement("transferpage_gohomepage_button").click();
		return new HomePage(driver);
	}
	
	public String getConfirmText(){
		Alert confirm = driver.switchTo().alert();
		String confirmText = confirm.getText();
		confirm.accept();	
		return confirmText;
	}
}
