package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class RechargePage2 extends BasePage {
	public RechargePage2(WebDriver driver){
		super(driver);
	}
	
	public void inputRechargeNum(String num){
		getElement("rechargepage2_inputrechargenum_input").sendKeys(num);
	}
	
	public void inputPassword(String password){
		getElement("rechargepage2_inputpassword_input").sendKeys(password);
	}
	
	public void doSumbit(){
		getElement("rechargepage2_submitdate_button").click();
	}
	
	public RechargeSuccessPage doRecharge(String num, String password){
		inputRechargeNum(num);
		inputPassword(password);
		doSumbit();
		return new RechargeSuccessPage(driver);
	}
}
