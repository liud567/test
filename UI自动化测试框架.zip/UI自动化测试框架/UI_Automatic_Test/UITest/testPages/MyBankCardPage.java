package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class MyBankCardPage extends BasePage {
	public MyBankCardPage(WebDriver driver){
		super(driver);
	}
	
	public int getCardsNum(){
		return getElements("mybankcardpage_allcards_eles").size();
	}
	
	public AccountManagementPage goToAccountManageentPage(){
//		getElement("homepage_accountmanage_button").click();
		click("homepage_accountmanage_button");
		return new AccountManagementPage(driver);
	}
	

}
