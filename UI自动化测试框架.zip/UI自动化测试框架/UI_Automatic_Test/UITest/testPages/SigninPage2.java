package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class SigninPage2 extends BasePage {
	
	public SigninPage2(WebDriver driver){
		super(driver);
	}

	public void inputPassword(String password){
		type("signinpage2_inputpassword_input", password);
	}
	
	public void inputPasswordAgain(String passwordagain){
		type("signinpage2_inputpasswordagain_input", passwordagain);
	}
	
	public void inputEmailAddress(String emailaddress){
		type("signinpage2_inputemail_input", emailaddress);
	}
	
	public void inputRealName(String realname){
		type("signinpage2_inputrealname_input", realname);
	}
	
	public void inputID(String id){
		type("signpage2_inputidno_input", id);
	}
	
	public void selectQ(String question){
		click("signpage2_selectQ_button");
		switch (question) {
		case "您父亲的出生地":
			click("signpage2_selectQ_button1");
			break;
		case "您的小学名称":
			click("signpage2_selectQ_button2");
			break;
		default:
			break;
		}
	}
	
	public void inputA(String answer){
		type("signpage2_inputA_input", "12345");
	}
	
	public void doSubmit(){
		click("signinpage2_submitbutton_button");
	}
	
	public LoginPage submitdata(String password, String passwordagain, String emailaddress, String realname, String id, String question, String answer){
		inputPassword(password);
		inputPasswordAgain(passwordagain);
		inputEmailAddress(emailaddress);
		inputRealName(realname);
		inputID(id);
		selectQ(question);
		inputA(answer);
		doSubmit();
		return new LoginPage(driver);
	}
}
