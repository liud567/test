package testPages;

import org.openqa.selenium.WebDriver;

import common.BasePage;

public class HomePage extends BasePage {
	public HomePage(WebDriver driver){
		super(driver);
	}
	
	public String getBalanceValue(){
		waitMs(500);
		return getElement("homepage_balance_text").getText().split(" ")[1];		
	}
	
	public RechargePage1 goToRecharge(){
		getElement("homepage_recharge_button").click();
		return new RechargePage1(driver);
	}
	
	public WithdrawPage goToWithdraw(){
		getElement("homepage_withdraw_button").click();
		return new WithdrawPage(driver);
	}
	
	public AccountManagementPage goToAccountManageent(){
		getElement("homepage_accountmanage_button").click();
		return new AccountManagementPage(driver);
	}
	
	public TransferPage goToTransfer(){
		getElement("homepage_transfer_button").click();
		return new TransferPage(driver);
	}
	
}
