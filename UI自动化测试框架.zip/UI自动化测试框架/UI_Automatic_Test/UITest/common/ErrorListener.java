package common;

import org.openqa.selenium.WebDriver;
import org.testng.ITestResult;
//import org.testng.Reporter;
import org.testng.TestListenerAdapter;
import common.ScreenShot;

public class ErrorListener extends TestListenerAdapter {

	Log log = new Log(this.getClass());

	@Override
	public void onTestStart(ITestResult tr) {
		super.onTestStart(tr);
		log.info("开始执行测试：" + tr.getName());
//		Reporter.log("开始执行测试：" + tr.getName());
	}

	@Override
	public void onTestFailure(ITestResult tr) {

		log.error(tr.getName() + " 执行失败");
//		Reporter.log(tr.getName() + " 执行失败");
		try {
			BaseTest tb = (BaseTest) tr.getInstance();
			WebDriver driver = tb.getDriver();
			ScreenShot a = new ScreenShot(driver);
			a.takeScreenshot(tr.getName());
			driver.close();
			driver.quit();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		}
		super.onTestFailure(tr);

	}

	@Override
	public void onTestSkipped(ITestResult tr) {
		super.onTestSkipped(tr);
		log.info(tr.getName() + " Skipped");
	}

	@Override
	public void onTestSuccess(ITestResult tr) {
		super.onTestSuccess(tr);
		log.info(tr.getName() + " 执行成功");
//		Reporter.log(tr.getName() + " 执行成功");
	}

}
