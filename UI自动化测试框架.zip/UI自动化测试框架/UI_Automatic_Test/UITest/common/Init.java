package common;

import java.io.File;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import testPages.FrontPage;
import testPages.LoginPage;

public class Init {

	public Log log = new Log(this.getClass());

	public WebDriver initAndLogin(String browser, String url, String username, String password) {
		switch (browser) {
		case "Ie": {
			//指定iedriver的目录，在项目中，这样，在换个新电脑后，driver不需要复制，可直接使用
			File driverpath = new File("UITest/drivers/IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", driverpath.getAbsolutePath());
			WebDriver driver = new InternetExplorerDriver();
			log.info("启动IE浏览器");
			doLogin(driver, url, username, password);
			return driver;
		}
		case "Firefox": {
			WebDriver driver = new FirefoxDriver();
			log.info("启动Firefox浏览器");
			doLogin(driver, url, username, password);
			return driver;
		}
		case "Chrome": {
			File driverpath = new File("UITest/drivers/chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", driverpath.getAbsolutePath());
			WebDriver driver = new ChromeDriver();
			log.debug("启动Chrome浏览器");
			doLogin(driver, url, username, password);
			return driver;
		}

		default: {
			log.error("输入的浏览器类型错误，请输入Ie、Firefox或Chrome");
			return null;
		}
		}
	}

	public void doLogin(WebDriver dr, String url, String username, String password) {
		dr.manage().window().maximize();
		log.info("打开URL: " + url);
		dr.get(url);
		log.info("进行登录，使用用户名: " + username + " 密码: " + password);
		FrontPage fp = new FrontPage(dr);
		LoginPage lp = fp.goToLoginPage();
		lp.doLogin(username, password, false);
	}

	public WebDriver init(String browser, String url) {
		switch (browser) {
		case "Ie": {
			File driverpath = new File("UITest/drivers/IEDriverServer.exe");
			System.setProperty("webdriver.ie.driver", driverpath.getAbsolutePath());
			WebDriver driver = new InternetExplorerDriver();
			driver.manage().window().maximize();
			log.info("启动IE浏览器");
			driver.get(url);
			log.info("打开URL: " + url);
			return driver;
		}
		case "Firefox": {
			WebDriver driver = new FirefoxDriver();
			driver.manage().window().maximize();
			log.info("启动Firefox浏览器");
			driver.get(url);
			log.info("打开URL: " + url);
			return driver;
		}
		case "Chrome": {
			File driverpath = new File("UITest/drivers/chromedriver.exe");
			System.setProperty("webdriver.chrome.driver", driverpath.getAbsolutePath());
			WebDriver driver = new ChromeDriver();
			driver.manage().window().maximize();
			log.info("启动Chrome浏览器");
			driver.get(url);
			log.info("打开URL: " + url);
			return driver;
		}

		default: {
			log.error("输入的浏览器类型错误，请输入Ie、Firefox或Chrome");
			return null;
		}
		}
	}

}
