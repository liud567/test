package common;

import org.openqa.selenium.WebDriver;

import testPages.FrontPage;
import testPages.SigninPage1;
import testPages.SigninPage2;

public class BaseTest {

	protected static WebDriver driver;
	
	protected static Assertion ae = new Assertion();
	
	protected static Init init = new Init();
	
	protected static FrontPage frontpage;
	protected static SigninPage1 signinpage1;
	protected static SigninPage2 signinpage2;

	public WebDriver getDriver() {
		return driver;
	}
	
	public void waitMs(int ms) {
		try {
			Thread.sleep(ms);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}

//	 @BeforeClass
//	 public void setUp(){
//	 driver = new FirefoxDriver();
//	 driver.manage().window().maximize();
//	 driver.navigate().to("http://www.baidu.com");
//	 }
	//
	// @AfterClass
	// public void tearDown(){
	// driver.close();
	// driver.quit();
	// }
}
